class TestMovie {
	public static void main(String[] args) {

		Movie m = new Movie();

		//m.printMovies();
        m.sort(0, 0);
        m.sort(1, 0);
        m.sort(2, 1);
	}
}

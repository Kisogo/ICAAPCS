public class Cube extends Box
{       
        /**
         * Constructor for objects of class rectangle
         */
        public Cube(int l)
        {
                /* construct the superclass object */
                super(l, l, l);
        }
}
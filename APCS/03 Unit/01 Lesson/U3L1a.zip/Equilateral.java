class Equilateral extends Triangle
{
    public Equilateral(double l)
    {
        super(l, l, l);
    }

}

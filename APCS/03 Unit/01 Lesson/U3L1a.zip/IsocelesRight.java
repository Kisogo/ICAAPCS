public class IsocelesRight extends Triangle
{
    public IsocelesRight(double l)
    {
        super(l, l, l * (Math.sqrt(2)));
    }
}

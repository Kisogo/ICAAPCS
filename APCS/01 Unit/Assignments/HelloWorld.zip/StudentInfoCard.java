/**
 * Name: Ryan Stenmark
 * Date: 2015-09-01
 * This program displays a Student Information Card.
 *
 */

class StudentInfoCard
{
	public static void main(String[] args)
	{
		System.out.println("+--------------------------------------------------------- +");
		System.out.println("|                                                          |");
	        System.out.println("|                   Student Information                    |");
		System.out.println("|                                                          |");
		System.out.println("+----------------------------------------------------------+\n\n");
		System.out.println("Name: Ryan Stenmark\tBirthday: 2/14/00\tAge: 15\n");
		System.out.println("School: iNaCA\t\tGrade: 10\tCity: Crystal Lake\n");
		System.out.println("Availiable: Su/Tu all day\n\t  : M/W/T/F/Sa before 5:00p / after 7:30p CST\n");
		System.out.print  ("Home Phone: 217-607-4845\n");
		System.out.print  ("Cell Phone: 217-607-4845\n\n");
		System.out.print  ("Current Math: H. Algebra 2\n");
		System.out.print  ("Programming Experience: Java Programming I\n\n");
		System.out.print  ("I am taking this course to generally further my understanding\nof computer programming.\n");

	}
}

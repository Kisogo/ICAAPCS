class CaesarShiftTester
{
	public static void main(String[] args)
	{
        Menu menu = new Menu();
	}
}

public interface Processing {
	void doReading();
}

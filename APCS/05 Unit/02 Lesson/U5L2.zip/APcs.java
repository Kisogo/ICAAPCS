public class APcs extends Homework {
    
    APcs() {
        super();
        setTypeHomework("APCS");
    }
    
    public void createAssignment(int p) {
        setPagesRead(p);
    }
}

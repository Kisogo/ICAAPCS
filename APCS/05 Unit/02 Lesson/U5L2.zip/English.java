public class English extends Homework {
    
    English() {
        super();
        setTypeHomework("English");
    }
    
    public void createAssignment(int p) {
        setPagesRead(p);
    }
}

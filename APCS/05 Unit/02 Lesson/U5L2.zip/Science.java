public class Science extends Homework {
    
    Science() {
        super();
        setTypeHomework("Science");
    }
    
    public void createAssignment(int p) {
        setPagesRead(p);
    }
}

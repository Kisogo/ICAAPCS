public class Math extends Homework {
    
    Math() {
        super();
        setTypeHomework("Math");
    }
    
    public void createAssignment(int p) {
        setPagesRead(p);
    }
}

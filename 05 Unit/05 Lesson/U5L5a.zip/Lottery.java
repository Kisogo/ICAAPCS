import java.util.Random;
import java.util.Scanner;

class Lottery
{
	public static void main(String[] args)
	{
		Random rng = new Random();
		Scanner in = new Scanner(System.in);
		
		// Generate lottery numbers and store them
		String[] winningnumbers = {"", "", ""};
		for(int i=0; i != 3; i++)
		{
			int nextRandInt = rng.nextInt(9); 
			winningnumbers[i] = Integer.toString(nextRandInt);
		}
		
		// Print the winning numbers for debug purposes
		System.out.print("[debug] winning number: " + winningnumbers[0] + winningnumbers[1] + winningnumbers[2] + "\n");
		
		
		// Get user's guess
		System.out.print("Please enter your three numbers (e.g. 123): ");
		String[] guess = in.nextLine().split("");
		
		// Make sure the user's guess is three numbers long
		if(guess.length != 3)
		{
			System.out.println("Make sure your guess is three numbers long!");
			System.exit(0);
		}
		
		// Check user's guess and construct a truth 'table' (it's an array)
		boolean[] truthtable = {false, false, false};
		for(int k=0; k != guess.length && k != winningnumbers.length; k++)
		{
			// Check numbers of user's guess
			if(guess[k].equals(winningnumbers[k]))
			{
				truthtable[k] = true;
			}
		}
			
		// figure out winning condition
		if(truthtable[0] && truthtable[1] && truthtable[2] == true)
		{
			// user's entire guess is correct
			System.out.println("Winner: " + winningnumbers[0] + winningnumbers[1] + winningnumbers[2]);
			System.out.println("Congratulations, both pairs matched.");
		}
		else if(truthtable[0] && truthtable[1] == true)
		{
			// user's first two guesses are correct
			System.out.println("Winner: " + winningnumbers[0] + winningnumbers[1] + winningnumbers[2]);
			System.out.println("Congratulations, the front pair matched.");
		}
		else if(truthtable[1] && truthtable[2] == true)
		{
			// user's last two guesses are correct
			System.out.println("Winner: " + winningnumbers[0] + winningnumbers[1] + winningnumbers[2]);
			System.out.println("Congratulations, the end pair matched.");
		}
		else
		{
			// none of user's guesses were correct.	
			System.out.println("Winner: " + winningnumbers[0] + winningnumbers[1] + winningnumbers[2]);
			System.out.println("Sorry, no matches.");
		}
	}
}
